<?php
    $dbc = mysqli_connect('localhost', 'f3106386_cms', 'ROaYl*WX~29f', 'f3106386_naaDB');
?>