<?php
    $dbc = mysqli_connect('localhost', 'goarmvzxat_1', 'NZiSrw6bKt8', 'goarmvzxat_db1','3306');
?>