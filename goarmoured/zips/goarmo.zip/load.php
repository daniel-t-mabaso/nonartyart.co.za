<div id="page-load">
    <div id="loader-container">
    <h3 class="white-txt text-from-center" style="width: 100%;">Loading</h3><div class="lds-roller"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>
</div>
</div>